def geturl(url):
    urls=url.split('/')
    url=urls[0]+'//'+urls[2]+'/'+urls[3]+'/'
    return url